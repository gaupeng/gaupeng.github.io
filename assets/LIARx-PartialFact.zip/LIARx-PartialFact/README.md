# LIARx: A Partial Fact Fake News Dataset
## Overview
LIARx is a partial fact dataset which is an updated form of the popular LIAR dataset published by William Yang Wang in 2017 in the domain of US Politics. The proposed partial fact dataset addresses the non-binary nature of fake news and instead allows you to learn the degree of veracity of each instance.

The LIARx dataset extends from the LIAR dataset, which contains data only until 2017 (when the dataset was published), and adds newer data points, containing data until the end of January, 2021. While LIAR generously encompassed several features into their data set, LIARx proposed here is put forward with the idea of showcasing the feasibility of LDL to capture non-binary nature of fakeness based solely on the information itself.

## Features
LIARx contains only the textual statements and the degree of truth or fakeness. It consists of 3 columns 

- Column 1: the statement
- Column 2: the degree of truth
- Column 3: the degree of fakeness (1 - degree of truth)

Note that we do not provide the full-text verdict report in this current version of the dataset, but you can use the following source to access the full verdict report. 
https://www.politifact.com/ 

The partial fact dataset deals wih 2 labels [True, False]. Every instance of the dataset has only three possibilities i.e. two fake news statements, two non-fake news statements, one fake news statement with one non-fake news statement referred to as Completely false, completely true and partially true  instances. The labels are represented by [0, 1], [1, 0], [0.5, 0.5] respectively. The original test-train-validate ratio of statements in LIAR is maintained for LIARx dataset that consists of 8.6k instances.  

-------------------------------------------
The original sources retain the copyright of the data.

Note that there are absolutely no guarantees with this data, and we provide this dataset "as is", but you are welcome to report the issues of the preliminary version of this data. You are allowed to use this dataset for research purposes only.

For more question about the dataset, please contact:
Sharanya Venkat, sharanyavenkat25@gmail.com
Richa, richa5june99@gmail.com
Gaurang Rao, gaurangpesu@gmail.com
Bhaskarjyoti Das, bhaskarjyoti01@gmail.com

Dataset Link : https://gaupeng.xyz/assets/LIARx-PartialFact.zip

v1.0 04/27/2021





